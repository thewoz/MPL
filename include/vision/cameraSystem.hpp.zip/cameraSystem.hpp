/*
 * MIT License
 *
 * Copyright © 2017 COBBS
 * Created by Leonardo Parisi (leonardo.parisi[at]gmail.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */



#ifndef _COBBS_VISION_CAMERASYSTEM_H_
#define _COBBS_VISION_CAMERASYSTEM_H_


template <typename ... args>
struct allsame : public std::false_type {};


template <typename T>
struct allsame<T> : public std::true_type {};


template <typename T, typename ... args>
struct allsame<T, T, args...> : public allsame<T, args ... > {};

template <typename... args>
typename std::tuple_element<0, std::tuple<args...> >::type * make_arr(args... arg) {
  
  // Code to check if passed args are of the same type
  static_assert(allsame<args ...>::value, "Params must have same types");
  
  typedef typename std::tuple_element<0, std::tuple<args...> >::type T;
  
  T* arr = new T[sizeof...(arg)]{ arg... };
  
  return arr;
  
};


#include <cstdlib>
#include <cstdio>

#include <array>
#include <tuple>

#include <opencv2/opencv.hpp>

#include "../stdio.hpp"

#include "camera.hpp"
#include "undistort.hpp"
#include "reprojection.hpp"
#include "reconstruction.hpp"

#define CAM(num) (num-1)

/*****************************************************************************/
// namespace vision
/*****************************************************************************/
namespace vision {
  
  /*****************************************************************************/
  // class cameraSystem_t
  /*****************************************************************************/
  template <std::size_t N>
  class cameraSystem_t {
    
  private:
    
    std::array<vision::camera_t, N> cameras;
    
    std::array< std::array<cv::Mat, N>, N> fundamentalMatrix;

    
  public:
    
    inline std::size_t cameraNumber() const { return N; }
    
    /*****************************************************************************/
    // initFundamentalMatrix
    /*****************************************************************************/
    void initFundamentalMatrix(){      
      
      for(std::size_t i=0; i<N; ++i){
        
        for(std::size_t j=0; j<N; ++j){

          if(i==j) continue;
          
          fundamentalFromProjections(cameras[i].getProjectionMatrix(), cameras[i].getProjectionMatrix(), fundamentalMatrix[i][j]);
          
        }
        
      }
    
    }
    
    /*****************************************************************************/
    // undistort
    /*****************************************************************************/
    template<typename T>
    void undistort(const std::vector<T> & src, std::vector<T> & dst, uint32_t camera) {
     
      if(camera > N){
        fprintf(stderr, "errro\n");
        abort();
      }
      
      vision::undistort(src, dst, cameras[camera].getCameraMatrix(), cameras[index].getDistortionCoefficients());

    }

    /*****************************************************************************/
    // reproject
    /*****************************************************************************/
    template<typename T3D, class ... args>
    void reproject(const cv::Point3_<T3D> & point3D, args & ... list) { reproject(point3D, & list ...); }
    
    template<typename T3D, class ... args>
    void reproject(const cv::Point3_<T3D> & point3D, args * ... list) {

      static_assert(sizeof...(list)==N, "Wrong params number");

      static_assert(allsame<args ... >::value, "Params must have same types");
      
      typedef typename std::tuple_element<0, std::tuple<args...> >::type T;
      
      T * points2D = new T[sizeof...(list)]{ * list ... };
      
      for(uint32_t i=0; i<N; ++i)
        vision::reproject(point3D, points2D[i], cameras[i].getProjectionalMatrix());
      
      delete[] points2D;

    }
    
    
    /*****************************************************************************/
    // reconstruct
    /*****************************************************************************/
    template<typename T3D, class ... args>
    void reconstruct(cv::Point3_<T3D> & point3D, const args & ... list) { return reconstruct(point3D, & list ...); }
    
    template<typename T3D, class ... args>
    void reconstruct(cv::Point3_<T3D> & point3D, const args * ... list) {
      
      typedef typename std::tuple_element<0, std::tuple<args...> >::type T2D;
      
      static_assert(std::is_same<T3D, float  >::value ||
                    std::is_same<T3D, double >::value, "use a undefine specialization");
     
      static_assert(std::is_same<T2D, cv::Point_<float>   >::value ||
                    std::is_same<T2D, cv::Point_<double>  >::value, "use a undefine specialization");
      
      static_assert(sizeof...(list)==N, "Wrong params number");
      
      static_assert(allsame<args ... >::value, "Params must have same types");
      
      const T2D * points2D = new T2D[sizeof...(list)]{ * list ... };
      
      if constexpr (N==3)
      
        vision::reconstruct(points2D[0], cameras[0].getProjectionalMatrix(),
                            points2D[1], cameras[1].getProjectionalMatrix(),
                            points2D[2], cameras[2].getProjectionalMatrix(),
                            point3D);
      else
        static_assert(true, "Wrong params number");
      
      delete[] points2D;
      
    }
    
    
    /*****************************************************************************/
    // reconstruct
    /*****************************************************************************/
    template<typename T3D, class ... args>
    auto reconstruct(const args * ... list) {
      
      static_assert(std::is_same<T3D, float>::value ||
                    std::is_same<T3D, double>::value, "use a undefine specialization");
      
      cv::Point3_<T3D> point3D;
      
      reconstruct(point3D, * list ...);
      
      return point3D;
      
    }
    
    template<typename T3D, class ... args>
    auto reconstruct(const args & ... list) { return reconstruct<T3D>(& list ...); }
    
    
    
    /*****************************************************************************/
    // reconstruct
    /*****************************************************************************/
    //template<class ... args>
    //double reconstructionError(args ... list) = delete;
      
    //template<class ... args>
    //double reconstructionError(const args & ... list) {
    
      /*
      
      static_assert(sizeof...(list)==N, "Wrong params number");
      
      static_assert(allsame<args ... >::value, "Params must have same types");
      
      typedef typename std::tuple_element<0, std::tuple<args...> >::type T;
      
      static_assert(std::is_same<T, cv::Point_<float>   >::value ||
                    std::is_same<T, cv::Point_<double>  >::value, "use a undefine specialization");
      
      const T * points2D = new T[sizeof...(list)]{ * list ... };
      
      double error;
      
      if constexpr (N==3)
        
        error = vision::reconstruction::error(points2D[0], cameras[0].getProjectionalMatrix(),
                                      points2D[1], cameras[1].getProjectionalMatrix(),
                                      points2D[2], cameras[2].getProjectionalMatrix());
      
      else
        static_assert(true, "Wrong params number");
      
      delete[] points2D;
      
      return error;
      
    }
    */
    //template<class ... args>
    //double reconstructionError(const args & ... list) { return reconstructionError(& list ...); }
    
    
    
    /*****************************************************************************/
    // undistort
    /*****************************************************************************/
    /*
    template<class ... type>
    void undistort(type ... args) {

      std::tuple<type ...> list = {args...};
      
      //std::array<std::vector<cv::Point2f> & , sizeof...(args)> list = {args...};
    
      if(list.size() != N && list.size() != 2*N){
        fprintf(stderr, "errro\n");
        abort();
      }
      
      if(list.size() == N){
      
        for(std::size_t i=0; i<N; ++i)
          vision::undistort(list[i], cameras[i]);
        
      }
      
      if(list.size() == 2*N){
        
        for(std::size_t i=0; i<N; ++i)
          vision::undistort(list[i], list[i+1], cameras[i]);
        
      }
      
    }
     */
    
    /*****************************************************************************/
    // loadProjectionMatrices
    /*****************************************************************************/
    void loadProjectionMatrices(const char * file) {
      
      FILE * input = io::openf(file,"r");
      
      char line[PATH_MAX];
      
      uint32_t lineRead = 0;
      
      // ciclo su tutte le linee del file
      while(fgets(line, PATH_MAX, input)){
        
        if(lineRead < N)
          cameras[lineRead].initCamera(line);
        
        ++lineRead;
        
      }
      
      if(lineRead < N){
        fprintf(stderr, "error\n");
        abort();
      }
      
      if(lineRead > N){
        fprintf(stderr, "waring\n");
      }
      
      io::closef(input);
      
    }

    template <class ... args,  typename T >
    double reconstructionError(args ... list) = delete;
    
  }; /* class cameraSystem_t */

  
  
  template <> template <>  template <typename T>
  double cameraSystem_t<3>::reconstructionError(cv::Point_<T> pt1, cv::Point_<T> pt2, cv::Point_<T> pt3, double maxError){
    
    return 3.0;
  
  }

  typedef cameraSystem_t<1> cameraSystem1_t;
  typedef cameraSystem_t<2> cameraSystem2_t;
  typedef cameraSystem_t<3> cameraSystem3_t;
  
} /* namespace vision */





















#if(0)
/*****************************************************************************/
// reproject
/*****************************************************************************/
template<typename T3D, class ... args>
void reproject(const cv::Point3_<T3D> & point3D, args & ... list) { reproject(point3D, & list ...); }


template<typename T3D, class ... args>
void reproject(const cv::Point3_<T3D> & point3D, args * ... list) {
  
  static_assert(sizeof...(list)==N, "Wrong params number");
  
  static_assert(allsame<args ... >::value, "Params must have same types");
  
  typedef typename std::tuple_element<0, std::tuple<args...> >::type T;
  
  T * points2D = new T[sizeof...(list)]{ * list ... };
  
  for(uint32_t i=0; i<N; ++i)
    vision::reproject(point3D, points2D[i], cameras[i].getProjectionalMatrix());
  
  delete[] points2D;
  
}
#endif


#endif /* _COBBS_VISION_CAMERASYSTEM_H_ */
